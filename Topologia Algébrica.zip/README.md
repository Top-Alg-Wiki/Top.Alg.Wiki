# Top.Alg.Wiki
Nesse projeto vamos criar uma wikipedia da topologia algébrica como parte da matéria MAT431 (Introdução à topologia algébrica) ministrada no IME-USP pelo Prof. Dr. Ivan Struchiner, com auxílio da monitora Bianca Carvalho de Oliveira.

Para contribuir por favor leia o arquivo *contributing.md*.
