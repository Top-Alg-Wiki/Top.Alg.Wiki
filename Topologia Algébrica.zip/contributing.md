# Contribuições

 - Contribuições ao projetos devem ser compiladas antes de abrir o Pull Request. Pull Request's que não compilem serão imediatamente rejeitados;
 - Contribuições só podem ser feitas à pasta "conteudo", com exceção da adição de novos capítulos do documento principal, "Alg.Top-Wiki";
 - inclusão de capítulos e secções devem ser feitas apartir de agora pelo comando \input{ĉonteudo/documento}, onde o arquivo tex tem nome documento.tex
 - Não fazer nenhuma alteração à pasta Alg.Top-Wiki.

   Mais regras à serem definidas.
